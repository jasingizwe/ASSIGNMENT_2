/* utxo_simulation.c
   Simple UTXO model simulator.
   - Maintains a list of UTXOs
   - Allows transactions by selecting UTXOs (manual or auto)
   - Creates new UTXOs for receiver and change for sender
   - Marks input UTXOs as spent
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define MAX_UTXOS 200
#define ADDR_LEN 64

typedef struct {
    int id;                     // unique UTXO id
    char address[ADDR_LEN];     // owner's address
    int amount;                 // integer amount (satoshis-like)
    bool spent;                 // whether this UTXO has been spent
} UTXO;

UTXO utxos[MAX_UTXOS];
int utxo_count = 0;
int next_utxo_id = 1;

/* add_utxo: create a new UTXO */
void add_utxo(const char *addr, int amount) {
    if (utxo_count >= MAX_UTXOS) {
        printf("ERROR: UTXO storage full\n");
        return;
    }
    utxos[utxo_count].id = next_utxo_id++;
    strncpy(utxos[utxo_count].address, addr, ADDR_LEN-1);
    utxos[utxo_count].address[ADDR_LEN-1] = '\0';
    utxos[utxo_count].amount = amount;
    utxos[utxo_count].spent = false;
    utxo_count++;
}

/* print_utxos: show all UTXOs and their status */
void print_utxos() {
    printf("\n=== Current UTXO Set ===\n");
    printf("ID\tAddress\t\tAmount\tStatus\n");
    for (int i = 0; i < utxo_count; ++i) {
        printf("%d\t%-10s\t%d\t%s\n",
               utxos[i].id,
               utxos[i].address,
               utxos[i].amount,
               utxos[i].spent ? "SPENT" : "UNSPENT");
    }
    printf("========================\n\n");
}

/* find_utxo_index_by_id: return index in array or -1 */
int find_utxo_index_by_id(int id) {
    for (int i = 0; i < utxo_count; ++i)
        if (utxos[i].id == id) return i;
    return -1;
}

/* print_unspent_for_address: helper to show user's unspent UTXOs */
void print_unspent_for_address(const char *addr) {
    printf("Unspent UTXOs for %s:\n", addr);
    bool found = false;
    for (int i = 0; i < utxo_count; ++i) {
        if (!utxos[i].spent && strcmp(utxos[i].address, addr) == 0) {
            printf("  ID: %d  Amount: %d\n", utxos[i].id, utxos[i].amount);
            found = true;
        }
    }
    if (!found) printf("  (none)\n");
}

/* process_transaction: core logic (used by demo + interactive)
   - If auto_select == 1, we select UTXOs automatically until amount satisfied.
   - If auto_select == 0, sel_ids[] with sel_count must be provided (indexes of utxos array).
   Returns 1 on success, 0 on failure.
*/
int process_transaction(const char *sender, const char *receiver, int amount,
                        int auto_select, int sel_ids[], int sel_count) {
    int total = 0;
    int selected_indexes[50];
    int selected_count = 0;

    if (auto_select) {
        for (int i = 0; i < utxo_count && total < amount; ++i) {
            if (!utxos[i].spent && strcmp(utxos[i].address, sender) == 0) {
                selected_indexes[selected_count++] = i;
                total += utxos[i].amount;
            }
        }
    } else {
        // validate provided sel_ids (they are UTXO IDs)
        for (int j = 0; j < sel_count; ++j) {
            int idx = find_utxo_index_by_id(sel_ids[j]);
            if (idx == -1) {
                printf("ERROR: UTXO id %d not found\n", sel_ids[j]);
                return 0;
            }
            if (utxos[idx].spent) {
                printf("ERROR: UTXO id %d already spent\n", sel_ids[j]);
                return 0;
            }
            if (strcmp(utxos[idx].address, sender) != 0) {
                printf("ERROR: UTXO id %d does not belong to %s\n", sel_ids[j], sender);
                return 0;
            }
            selected_indexes[selected_count++] = idx;
            total += utxos[idx].amount;
        }
    }

    if (total < amount) {
        printf("ERROR: insufficient funds for %s (available %d, needed %d)\n", sender, total, amount);
        return 0;
    }

    // mark inputs spent
    for (int i = 0; i < selected_count; ++i) {
        utxos[selected_indexes[i]].spent = true;
    }

    // create receiver UTXO
    add_utxo(receiver, amount);

    // create change UTXO if needed
    int change = total - amount;
    if (change > 0) add_utxo(sender, change);

    printf("Transaction: %s -> %s : %d (inputs sum=%d, change=%d)\n", sender, receiver, amount, total, change);
    return 1;
}

/* init_demo_utxos: initialize UTXO set for demo */
void init_demo_utxos() {
    add_utxo("Alice", 50);    // id 1
    add_utxo("Alice", 30);    // id 2
    add_utxo("Bob", 70);      // id 3
    add_utxo("Bob", 20);      // id 4
    add_utxo("Carol", 100);   // id 5
}

/* run_demo: show two sample transactions automatically */
void run_demo() {
    printf("=== Demo mode: pre-initialized UTXOs and two transactions ===\n");
    init_demo_utxos();
    print_utxos();

    // 1) Alice pays Bob 60 -- auto-select should pick 50+30 = 80 -> change 20 to Alice
    printf("\nDemo tx 1: Alice pays Bob 60 (auto-select)\n");
    process_transaction("Alice", "Bob", 60, 1, NULL, 0);
    print_utxos();

    // 2) Bob pays Carol 50 -- auto-select uses Bob's UTXOs
    printf("\nDemo tx 2: Bob pays Carol 50 (auto-select)\n");
    process_transaction("Bob", "Carol", 50, 1, NULL, 0);
    print_utxos();

    printf("=== Demo complete ===\n");
}

/* interactive mode for user to perform transactions */
void interactive_mode() {
    char sender[ADDR_LEN], receiver[ADDR_LEN], choice[8];
    int amount;

    // keep small menu loop
    while (1) {
        printf("\nMenu:\n  1) Show UTXOs\n  2) New transaction\n  3) Exit\nChoose: ");
        int opt;
        if (scanf("%d", &opt) != 1) { // handle bad input
            while (getchar()!='\n'); // flush
            continue;
        }
        if (opt == 1) {
            print_utxos();
        } else if (opt == 2) {
            printf("Sender address: ");
            scanf("%s", sender);
            printf("Receiver address: ");
            scanf("%s", receiver);
            printf("Amount to send (integer): ");
            scanf("%d", &amount);

            print_unspent_for_address(sender);
            printf("Select UTXOs automatically or manually? (a = auto, m = manual): ");
            scanf("%s", choice);

            if (choice[0] == 'm') {
                printf("Enter UTXO ids to use separated by spaces, end with 0:\n");
                int id;
                int sel_ids[50];
                int sel_count = 0;
                while (1) {
                    if (scanf("%d", &id) != 1) break;
                    if (id == 0) break;
                    sel_ids[sel_count++] = id;
                }
                process_transaction(sender, receiver, amount, 0, sel_ids, sel_count);
                print_utxos();
            } else {
                process_transaction(sender, receiver, amount, 1, NULL, 0);
                print_utxos();
            }
        } else if (opt == 3) {
            printf("Exiting interactive mode.\n");
            break;
        } else {
            printf("Invalid option.\n");
        }
    }
}

int main(int argc, char *argv[]) {
    printf("UTXO Simulation - C\n");
    if (argc > 1) {
        if (strcmp(argv[1], "demo") == 0) {
            run_demo();
            return 0;
        }
    }
    // by default start with a fresh set you can interact with
    init_demo_utxos(); // pre-seed with some UTXOs so you can transact immediately
    interactive_mode();
    return 0;
}
