Account Model Simulation - README

Files:
 - account_model_simulation.c
 - README_account.txt

How the code works:
 - Maintains accounts (name, balance).
 - transferFunds(sender_idx, receiver_idx, amount) validates sufficient funds and updates balances.
 - Demo mode: ./account_model_simulation demo
 - Interactive: ./account_model_simulation

Sample accounts (demo):
 - Alice: 100, Bob: 50, Carol: 200
 - Demo transfers: Alice->Bob 70, Carol->Alice 30

Compile:
 - gcc account_model_simulation.c -o account_model_simulation