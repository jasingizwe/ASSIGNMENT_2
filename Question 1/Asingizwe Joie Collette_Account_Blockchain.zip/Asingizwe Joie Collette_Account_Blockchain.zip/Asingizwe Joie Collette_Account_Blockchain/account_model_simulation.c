/* account_model_simulation.c
   Simple Account/Balance model simulator.
   - Maintains accounts with balances
   - Allows transfers if sender has sufficient funds
*/

#include <stdio.h>
#include <string.h>

#define MAX_ACCOUNTS 10
#define NAME_LEN 64

typedef struct {
    char name[NAME_LEN];
    int balance; // integer for simplicity
} Account;

Account accounts[MAX_ACCOUNTS];
int account_count = 0;

/* add_account: create account with initial balance */
void add_account(const char *name, int balance) {
    if (account_count >= MAX_ACCOUNTS) return;
    strncpy(accounts[account_count].name, name, NAME_LEN-1);
    accounts[account_count].name[NAME_LEN-1] = '\0';
    accounts[account_count].balance = balance;
    account_count++;
}

void print_accounts() {
    printf("\nAccounts:\n");
    printf("Index\tName\tBalance\n");
    for (int i = 0; i < account_count; ++i) {
        printf("%d\t%-8s\t%d\n", i, accounts[i].name, accounts[i].balance);
    }
    printf("\n");
}

int find_account_index_by_name(const char *name) {
    for (int i = 0; i < account_count; ++i)
        if (strcmp(accounts[i].name, name) == 0) return i;
    return -1;
}

/* transferFunds: returns 1 on success, 0 on failure */
int transferFunds(int sender_idx, int receiver_idx, int amount) {
    if (sender_idx < 0 || receiver_idx < 0 || sender_idx >= account_count || receiver_idx >= account_count) {
        printf("ERROR: invalid account index\n");
        return 0;
    }
    if (amount <= 0) {
        printf("ERROR: amount must be positive\n");
        return 0;
    }
    if (accounts[sender_idx].balance < amount) {
        printf("ERROR: insufficient balance. %s has %d, needs %d\n",
               accounts[sender_idx].name, accounts[sender_idx].balance, amount);
        return 0;
    }
    accounts[sender_idx].balance -= amount;
    accounts[receiver_idx].balance += amount;
    printf("Transfer successful: %s -> %s : %d\n",
           accounts[sender_idx].name, accounts[receiver_idx].name, amount);
    return 1;
}

void init_demo_accounts() {
    add_account("Alice", 100);
    add_account("Bob", 50);
    add_account("Carol", 200);
}

/* demo: show pre-defined transfers */
void run_demo() {
    printf("=== Account model demo ===\n");
    init_demo_accounts();
    print_accounts();

    printf("Demo transfer 1: Alice -> Bob : 70\n");
    transferFunds(find_account_index_by_name("Alice"), find_account_index_by_name("Bob"), 70);
    print_accounts();

    printf("Demo transfer 2: Carol -> Alice : 30\n");
    transferFunds(find_account_index_by_name("Carol"), find_account_index_by_name("Alice"), 30);
    print_accounts();
}

/* interactive: allow user to transfer repeatedly */
void interactive_mode() {
    char sender[NAME_LEN], receiver[NAME_LEN];
    int amount;
    init_demo_accounts(); // seed accounts

    while (1) {
        printf("\nMenu:\n  1) Show accounts\n  2) Transfer funds\n  3) Exit\nChoose: ");
        int opt;
        if (scanf("%d", &opt) != 1) { while (getchar()!='\n'); continue; }
        if (opt == 1) {
            print_accounts();
        } else if (opt == 2) {
            printf("Sender name: "); scanf("%s", sender);
            printf("Receiver name: "); scanf("%s", receiver);
            printf("Amount (integer): "); scanf("%d", &amount);
            int sidx = find_account_index_by_name(sender);
            int ridx = find_account_index_by_name(receiver);
            transferFunds(sidx, ridx, amount);
            print_accounts();
        } else if (opt == 3) {
            printf("Exiting.\n");
            break;
        } else {
            printf("Invalid option.\n");
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc > 1 && strcmp(argv[1], "demo") == 0) {
        run_demo();
        return 0;
    }
    interactive_mode();
    return 0;
}
